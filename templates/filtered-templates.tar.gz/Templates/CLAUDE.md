# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Repository Is

This is the **Nuclei Templates** repository (from ProjectDiscovery). It contains YAML-based vulnerability detection templates used by the [Nuclei scanner](https://github.com/projectdiscovery/nuclei). Templates cover CVEs, misconfigurations, exposed panels, default logins, technology detection, and more.

## Common Commands

```bash
# Validate a template
nuclei -t path/to/template.yaml -validate

# Run a template against a target
nuclei -t path/to/template.yaml -u https://target.example.com

# Run with debug output (useful for verifying matchers)
nuclei -t path/to/template.yaml -u https://target.example.com -debug

# Run a scan profile
nuclei -profile recommended -u https://target.example.com

# Run templates by tag
nuclei -tags cve,critical -u https://target.example.com
```

## Repository Architecture

### Protocol-Based Template Directories (primary, curated)

Templates are organized first by **protocol**, then by **category**:

- **`http/`** — HTTP templates (~8600+), the largest set. Subdirectories: `cves/` (by year), `default-logins/`, `exposed-panels/`, `exposures/`, `fuzzing/`, `misconfiguration/`, `technologies/`, `vulnerabilities/`, `token-spray/`, `takeovers/`, `osint/`, `honeypot/`, `iot/`, `credential-stuffing/`, `cnvd/`, `global-matchers/`, `miscellaneous/`
- **`network/`** — TCP-based templates. Subdirectories: `cves/`, `detection/`, `default-login/`, `enumeration/`, `exposures/`, `misconfig/`, `vulnerabilities/`, `backdoor/`, `c2/`, `honeypot/`, `jarm/`
- **`cloud/`** — Cloud misconfig checks: `aws/`, `azure/`, `gcp/`, `alibaba/`, `kubernetes/`, `enum/`
- **`dns/`** — DNS record analysis (SPF, DMARC, BIMI, dangling CNAMEs, takeovers)
- **`ssl/`** — TLS/SSL checks (expired certs, weak ciphers, deprecated TLS, C2 detection)
- **`file/`** — Local file analysis: `keys/`, `logs/`, `malware/`, `webshell/`, language-specific dirs (`php/`, `python/`, `js/`, etc.)
- **`javascript/`** — JS-based protocol templates (backdoor, detection, enumeration, UDP)
- **`code/`** — Code execution templates (CVEs, privilege escalation, Windows-specific)
- **`dast/`** — Dynamic application security testing templates
- **`headless/`** — Browser-based (headless Chrome) templates for DOM XSS, prototype pollution
- **`passive/`** — Passive analysis templates

### Other Key Directories

- **`workflows/`** — Multi-step scan workflows that chain templates (detect tech → run matching CVEs)
- **`profiles/`** — Scan configuration profiles (`.yml` files defining severity, type, and exclusion lists). Key profiles: `recommended.yml`, `pentest.yml`, `cves.yml`, `cloud.yml`
- **`helpers/`** — Shared payloads (`payloads/`), wordlists (`wordlists/`), WordPress helpers
- **`CVE-YYYY/`** — Auto-generated community CVE templates (from Wordfence data). These use hashed filenames (e.g., `CVE-2025-0169-141bc5e3...yaml`). Distinct from the curated `http/cves/YYYY/` templates.
- **`Vulnerability-Templates/` through `Vulnerability-Templates5/`** — Large collections of community-contributed templates with various naming conventions

### Key Files

- **`cves.json`** — Structured CVE metadata index
- **`contributors.json`** — Author metadata
- **`TEMPLATES-STATS.json` / `TEMPLATES-STATS.md`** — Template count statistics by tag, author, directory, severity, type
- **`.new-additions`** — Recently added template paths
- **`.templates-index` / `.checksum`** — Internal index/integrity files used by Nuclei
- **`wappalyzer-mapping.yml`** — Maps Wappalyzer tech names to Nuclei tags for automatic scanning (`-as` flag)

## Template YAML Structure

Every template has this structure:

```yaml
id: unique-template-id          # Short, max 3-4 words (e.g., grafana-unauth-rce)

info:
  name: "Vendor Product Version - Vulnerability"
  author: github-username
  severity: critical|high|medium|low|info|unknown
  description: |
    Brief description of the vulnerability
  reference:
    - https://...
  classification:               # Optional but encouraged
    cvss-metrics: CVSS:3.1/...
    cvss-score: 9.8
    cve-id: CVE-YYYY-NNNNN
    cwe-id: CWE-NNN
  metadata:
    verified: true              # If tested against live/lab target
    max-request: 1
    vendor: vendorname
    product: productname
    shodan-query: "..."
    fofa-query: "..."
  tags: cve,cve2024,vendor,tech,severity

# Protocol block (one of: http, tcp, dns, ssl, file, javascript, headless, code)
http:
  - method: GET
    path:
      - "{{BaseURL}}/path"
    matchers:
      - type: word|regex|status|dsl
        words:
          - "match string"
    extractors:
      - type: regex|kval|json
        regex:
          - "pattern"
```

## Template Writing Conventions

- Use `{{BaseURL}}`, `{{Hostname}}`, `{{Host}}` for target variables
- Use `{{randstr}}` for random strings (file uploads, web shells)
- Use `{{username}}`, `{{password}}` for authenticated templates, `{{token}}` for key/token templates
- Use `cmd` variable for RCE templates for consistency
- Always include multiple matchers to prevent false positives — avoid matching on generic GET/POST data
- Add `part: body` or `part: header` to matchers to specify where to match
- Templates end with a `# digest:` comment line (signature for template integrity)
- Minimize requests per template
- CVE templates go in `http/cves/YYYY/CVE-YYYY-NNNNN.yaml` (or the appropriate protocol directory)
- If multiple templates exist for one technology, create a subfolder for it
